import React from 'react';
import './RegistrationForm.css';

function RegistrationForm(props) {
    return(
        <form>
            registration form here
        </form>
    )
}

export default RegistrationForm;