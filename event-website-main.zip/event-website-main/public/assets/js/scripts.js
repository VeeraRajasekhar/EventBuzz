$('.navbar a').click(function() {
    $(".navbar-collapse").collapse('hide');
});